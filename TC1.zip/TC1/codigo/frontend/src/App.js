import React, { useState } from "react";
import Home from "./Interfaces/Home";
import Names from "./Interfaces/solicitarName";
import PantallaJuego from "./Interfaces/PantallaJuego";
import Resultados from "./Interfaces/Resultados";

function App() {
  const [pantalla, setPantalla] = useState("home");
  const [jugadores, setJugadores] = useState({ jugador1: "", jugador2: "" });

  const iniciarJuego = () => setPantalla("names");
  const volverHome = () => setPantalla("home");

  const continuarJuego = (nombres) => {
    setJugadores(nombres);
    setPantalla("juego");
  };

  const verHistorial = () => setPantalla("resultados");

  return (
    <>
      {pantalla === "home" && <Home iniciarJuego={iniciarJuego} verHistorial={verHistorial} />}
      {pantalla === "names" && <Names volverHome={volverHome} Continuar={continuarJuego} />}
      {pantalla === "juego" && <PantallaJuego volverHome={volverHome} jugadores={jugadores} />}
      {pantalla === "resultados" && <Resultados volverHome={volverHome} />}
    </>
  );
}

export default App;
