const express = require("express");
const cors = require("cors");
const { numeroAleatorio, ValidarNumero } = require("./Funciones");

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());
const fs = require("fs");
const path = require("path");

let numeroSecreto = numeroAleatorio();
let tiempos = {};
let cronometrosActivos = {};
let intervalos = {};
let intentosTotales = {};
let historialIntentos = [];
let historialSecretos = [];
let playerOrder = [];
let matchesHistory = [];

// Limpia intervalos y reinicia estructuras (evita intervalos huérfanos)
const MATCHES_FILE = path.join(__dirname, "matches.json");
if (fs.existsSync(MATCHES_FILE)) {
  try {
    const data = fs.readFileSync(MATCHES_FILE, "utf8");
    matchesHistory = JSON.parse(data);
  } catch (err) {}
}
function resetEstructuras() {
  // limpiar intervalos existentes
  Object.keys(intervalos).forEach((j) => {
    if (intervalos[j]) {
      clearInterval(intervalos[j]);
      intervalos[j] = null;
    }
  });

  // reiniciar contenedores
  tiempos = {};
  cronometrosActivos = {};
  intervalos = {};
  intentosTotales = {};
  historialIntentos = [];
  historialSecretos = [];
  playerOrder = [];
}

// Registrar jugadores (asigna aleatoriamente quien inicia)
app.post("/api/cronometro/registrar", (req, res) => {
  const { jugadores } = req.body;
  if (!jugadores || !jugadores.jugador1 || !jugadores.jugador2) {
    return res.status(400).json({ mensaje: "Faltan jugadores" });
  }

  resetEstructuras();

  // Elegir aleatoriamente quien inicia
  const primero = Math.random() < 0.5 ? jugadores.jugador1 : jugadores.jugador2;
  const segundo =
    primero === jugadores.jugador1 ? jugadores.jugador2 : jugadores.jugador1;
  playerOrder = [primero, segundo];

  // Inicializar tiempos, cronómetros e intentos para ambos jugadores
  tiempos[primero] = 0;
  tiempos[segundo] = 0;
  cronometrosActivos[primero] = false;
  cronometrosActivos[segundo] = false;
  intentosTotales[primero] = 0;
  intentosTotales[segundo] = 0;

  // Generar primer secreto
  numeroSecreto = numeroAleatorio();
  console.log("Número secreto generado:", numeroSecreto);

  historialSecretos.push({
    numeroSecreto,
    asignadoA: playerOrder[0],
    ronda: 0,
    generadoEn: Date.now(),
  });

  res.json({
    mensaje: "Jugadores registrados correctamente",
    inicio: playerOrder[0],
    orden: playerOrder,
  });
});

// Validar intento (guarda jugador y ronda)
app.post("/api/validar", (req, res) => {
  const { numero, jugador, ronda } = req.body;

  // Incrementar contador de intentos
  if (jugador) {
    if (intentosTotales[jugador] === undefined) intentosTotales[jugador] = 0;
    intentosTotales[jugador] += 1;
  }

  const mensaje = ValidarNumero(numero, numeroSecreto);

  // Guardar intento en historial
  historialIntentos.push({
    jugador: jugador || null,
    numeroIntentado: numero,
    resultado: mensaje,
    numeroSecreto,
    timestamp: Date.now(),
    ronda: typeof ronda === "number" ? ronda : null,
  });

  // Si acierta, generar nuevo secreto y asignarlo al siguiente jugador
  if (mensaje === "Numero correcto, felicidades!") {
    const siguienteRonda = typeof ronda === "number" ? ronda + 1 : null;
    let asignadoA = null;
    if (
      siguienteRonda !== null &&
      Array.isArray(playerOrder) &&
      playerOrder.length === 2 &&
      typeof siguienteRonda === "number"
    ) {
      asignadoA = playerOrder[siguienteRonda % 2];
    }

    numeroSecreto = numeroAleatorio();
    console.log("Número secreto generado:", numeroSecreto);
    console.log(
      "Nuevo número secreto:",
      numeroSecreto,
      "asignadoA:",
      asignadoA
    );
    historialSecretos.push({
      numeroSecreto,
      jugador: jugador,
      ronda: siguienteRonda,
      generadoEn: Date.now(),
    });
  }
  res.json({ mensaje });
});

//  endpoint para devolver historial
app.get("/api/historial", (req, res) => {
  res.json({ historialIntentos, historialSecretos, intentosTotales, tiempos });
});

// Iniciar cronómetro
app.post("/api/cronometro/iniciar", (req, res) => {
  const { jugador } = req.body;
  if (!jugador) return res.status(400).json({ mensaje: "Falta jugador" });

  if (tiempos[jugador] === undefined) tiempos[jugador] = 0;

  if (cronometrosActivos[jugador]) {
    console.log(
      `Cronómetro ya activo para ${jugador}, no se crea otro intervalo.`
    );
    return res.json({ mensaje: `Cronómetro ya activo para ${jugador}` });
  }

  if (intervalos[jugador]) {
    clearInterval(intervalos[jugador]);
    intervalos[jugador] = null;
  }
  cronometrosActivos[jugador] = true;
  intervalos[jugador] = setInterval(() => {
    tiempos[jugador] += 1;
  }, 1000);

  res.json({ mensaje: `Cronómetro iniciado para ${jugador}` });
});

// Pausar cronómetro (limpia el intervalo y marca inactivo)
app.post("/api/cronometro/pausar", (req, res) => {
  const { jugador } = req.body;
  if (!jugador) return res.status(400).json({ mensaje: "Falta jugador" });

  if (intervalos[jugador]) {
    clearInterval(intervalos[jugador]);
    intervalos[jugador] = null;
  }
  cronometrosActivos[jugador] = false;

  console.log(
    `Cronómetro pausado para ${jugador} (tiempo final: ${
      tiempos[jugador] || 0
    })`
  );
  res.json({ mensaje: `Cronómetro pausado para ${jugador}` });
});

// Consultar tiempo
app.get("/api/cronometro/tiempo", (req, res) => {
  const { jugador } = req.query;
  if (!jugador) return res.status(400).json({ mensaje: "Falta jugador" });

  res.json({ tiempo: tiempos[jugador] || 0 });
});

// Endpoint para obtener resultado/ganador al final de la partida
app.get("/api/resultado", (req, res) => {
  const jugadoresRegistrados = Object.keys(tiempos);
  if (jugadoresRegistrados.length < 2) {
    return res.status(400).json({ mensaje: "Faltan jugadores registrados" });
  }

  // Tomar dos jugadores
  const jugadorA = jugadoresRegistrados[0];
  const jugadorB = jugadoresRegistrados[1];

  const statsA = {
    nombre: jugadorA,
    intentos: intentosTotales[jugadorA] || 0,
    tiempo: tiempos[jugadorA] || 0,
  };
  const statsB = {
    nombre: jugadorB,
    intentos: intentosTotales[jugadorB] || 0,
    tiempo: tiempos[jugadorB] || 0,
  };

  // Decidir ganador
  let ganador = null;
  if (statsA.intentos < statsB.intentos) ganador = statsA.nombre;
  else if (statsB.intentos < statsA.intentos) ganador = statsB.nombre;
  else {
    // empate en intentos
    if (statsA.tiempo < statsB.tiempo) ganador = statsA.nombre;
    else if (statsB.tiempo < statsA.tiempo) ganador = statsB.nombre;
    else ganador = null;
  }

  res.json({
    ganador,
    jugadores: [statsA, statsB],
  });
});
//recopila resumen de la partida
let calcularResumenPartida = () => {
  const RONDAS_TOTALES = 6;
  const resumenPorRonda = [];
  for (let ronda = 0; ronda < RONDAS_TOTALES; ronda++) {
    const intentoRonda = historialIntentos.find((it) => it.ronda === ronda);
    const asignadoA = intentoRonda ? intentoRonda.jugador : undefined;
    const intentosCount = historialIntentos.filter(
      (it) => it.ronda === ronda
    ).length;
    const secretoObj = historialSecretos.find((s) => s.ronda === ronda);
    const numeroSecreto = secretoObj ? secretoObj.numeroSecreto : undefined;

    resumenPorRonda.push({
      ronda,
      asignadoA,
      numeroSecreto,
      intentos: intentosCount,
      tiempoSegundos: null,
    });
  }

  // Calcula totales por jugador y agrega intentosPorRonda
  const jugadores = Object.keys(tiempos);
  const stats = {};
  jugadores.forEach((j) => {
    const intentosJugador = historialIntentos.filter(
      (it) => it.jugador === j
    ).length;
    // intentos por ronda para este jugador
    const intentosPorRonda = [];
    for (let ronda = 0; ronda < RONDAS_TOTALES; ronda++) {
      const count = historialIntentos.filter(
        (it) => it.jugador === j && it.ronda === ronda
      ).length;
      intentosPorRonda.push({ ronda, intentos: count });
    }
    stats[j] = {
      nombre: j,
      totalIntentos: intentosJugador,
      totalTiempoSegundos: tiempos[j] || 0,
      intentosPorRonda,
    };
  });

  // Decide ganador
  let ganador = null;
  if (jugadores.length === 2) {
    const [A, B] = jugadores;
    if (stats[A].totalIntentos < stats[B].totalIntentos) ganador = A;
    else if (stats[B].totalIntentos < stats[A].totalIntentos) ganador = B;
    else if (stats[A].totalTiempoSegundos < stats[B].totalTiempoSegundos)
      ganador = A;
    else if (stats[B].totalTiempoSegundos < stats[A].totalTiempoSegundos)
      ganador = B;
    else ganador = null;
  }

  return {
    creadoEn: Date.now(),
    resumenPorRonda,
    stats,
    ganador,
  };
};

// POST /api/partida/finalizar
app.post("/api/partida/finalizar", (req, res) => {
  try {
    const resumen = calcularResumenPartida();
    matchesHistory.push(resumen);

    // Guardar en archivo JSON
    try {
      fs.writeFileSync(MATCHES_FILE, JSON.stringify(matchesHistory, null, 2));
    } catch (err) {}

    res.json(resumen);
  } catch (err) {
    res.status(500).json({ mensaje: "Error finalizando partida" });
  }
});

// GET /api/resultados
app.get("/api/resultados", (req, res) => {
  res.json({ matchesHistory: matchesHistory || [] });
});

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
