import React, { useState, useEffect } from "react";

function PantallaJuego({ volverHome, jugadores }) {
  const RONDAS_TOTALES = 6;
  const [rondaActual, setRondaActual] = useState(0);
  const [intento, setIntento] = useState("");
  const [mensaje, setMensaje] = useState("");
  const [historialIntentos, setHistorialIntentos] = useState([]);
  const [contadorIntentos, setContadorIntentos] = useState(0);
  const [tiempo, setTiempo] = useState(0);
  const [resumen, setResumen] = useState(null);

  // Determinar qué jugador está jugando
  const getJugador = (ronda) => {
    if (ronda >= RONDAS_TOTALES) return null;
    return ronda % 2 === 0 ? jugadores.jugador1 : jugadores.jugador2;
  };

  const jugador = getJugador(rondaActual);

  useEffect(() => {
    if (rondaActual === 0 && jugador) {
      fetch("http://localhost:3001/api/cronometro/iniciar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jugador }),
      });
    }
  }, [jugador, rondaActual]);

  // Consultar el tiempo del jugador actual cada segundo
  useEffect(() => {
    let activo = true;
    const actualizarTiempo = async () => {
      if (jugador) {
        try {
          const res = await fetch(
            `http://localhost:3001/api/cronometro/tiempo?jugador=${jugador}`
          );
          const data = await res.json();
          if (activo) setTiempo(data.tiempo);
        } catch {
          if (activo) setTiempo(0);
        }
      }
    };
    actualizarTiempo();
    const intervalo = setInterval(actualizarTiempo, 1000);
    return () => {
      activo = false;
      clearInterval(intervalo);
    };
  }, [jugador]);

  useEffect(() => {
    setContadorIntentos(0);
  }, [jugador, rondaActual]);

  const enviarIntento = async () => {
    if (intento === "") return;
    setContadorIntentos((prev) => prev + 1);
    try {
      const response = await fetch("http://localhost:3001/api/validar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          numero: Number(intento),
          jugador,
          ronda: rondaActual,
        }),
      });

      const data = await response.json();

      setHistorialIntentos([
        ...historialIntentos,
        { rondaActual, jugador, intento, resultado: data.mensaje },
      ]);

      setMensaje(data.mensaje);

      if (data.mensaje === "Numero correcto, felicidades!") {
        try {
          await fetch("http://localhost:3001/api/cronometro/pausar", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ jugador }),
          });

          const siguienteJugador =
            (rondaActual + 1) % 2 === 0
              ? jugadores.jugador1
              : jugadores.jugador2;

          if (rondaActual + 1 < RONDAS_TOTALES) {
            await fetch("http://localhost:3001/api/cronometro/iniciar", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ jugador: siguienteJugador }),
            });
          }
        } catch (error) {
          console.error("Error al pausar/iniciar cronómetro:", error);
        }

        if (rondaActual + 1 >= RONDAS_TOTALES) {
          const res = await fetch(
            "http://localhost:3001/api/partida/finalizar",
            {
              method: "POST",
            }
          );
          const resumenData = await res.json();
          setResumen(resumenData);
        }

        setRondaActual(rondaActual + 1);
        setContadorIntentos(0);
      }
    } catch (error) {
      console.error("Error al enviar intento:", error);
      setMensaje("Error de conexión con el servidor");
    }
  };

  //resumen al finalizar
  const PopupResumen = ({ resumen, onClose }) => (
    <div className="popup-overlay">
      <div className="popup-content resumen-popup">
        <h2>Resumen de la partida</h2>
        <h4>Jugadores:</h4>
        <ul>
          {Object.values(resumen.stats).map((s) => (
            <li key={s.nombre}>
              <strong>{s.nombre}</strong> — Intentos: {s.totalIntentos} —
              Tiempo: {s.totalTiempoSegundos} s
            </li>
          ))}
        </ul>
        <h4>Intentos por ronda:</h4>
        <table className="tabla-resumen">
          <thead>
            <tr>
              <th>Ronda</th>
              <th>Jugador</th>
              <th>Intentos</th>
            </tr>
          </thead>
          <tbody>
            {(resumen.resumenPorRonda || []).map((r) => (
              <tr key={r.ronda}>
                <td>{r.ronda + 1}</td>
                <td>{r.asignadoA}</td>
                <td>{r.intentos}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <h4>Ganador:</h4>
        <p>
          {resumen.ganador ? <b>{resumen.ganador}</b> : <span>Empate</span>}
        </p>
        <button className="btn-volver-verde" onClick={onClose}>
          Volver
        </button>
      </div>
    </div>
  );

  return (
    <div className="PantallaJuego">
      <div className="header-info">
        <div>Cronómetro: {tiempo} s</div>
        <div>Intentos: {contadorIntentos}</div>
      </div>
      <header>
        <h1>Batalla de números</h1>
        {rondaActual < RONDAS_TOTALES ? (
          <h2>
            Ronda {rondaActual + 1} - Turno de {jugador}
          </h2>
        ) : (
          <h2>El juego ha finalizado.</h2>
        )}
      </header>
      <main>
        {rondaActual < RONDAS_TOTALES && (
          <>
            <input
              type="number"
              value={intento}
              onChange={(e) => setIntento(e.target.value)}
              placeholder="Ingresa tu intento"
            />
            <button className="btn-enviar" onClick={enviarIntento}>
              Enviar intento
            </button>
          </>
        )}

        {mensaje && <p>{mensaje}</p>}

        <h3>Historial de intentos:</h3>
        <div className="terminal-historial">
          <ul>
            {historialIntentos.map((item, index) => (
              <li key={index}>
                Ronda {item.rondaActual + 1} - {item.jugador} intentó{" "}
                {item.intento}
                {item.resultado === "Numero correcto, felicidades!" ? (
                  <span className="pista correcto">✔ Correcto</span>
                ) : (
                  <span className="pista">
                    {item.resultado.includes("mayor")
                      ? "↑ Mayor"
                      : item.resultado.includes("menor")
                      ? "↓ Menor"
                      : ""}
                  </span>
                )}
              </li>
            ))}
          </ul>
        </div>
      </main>

      <button className="btn-cancelar" onClick={volverHome}>
        Cerrar
      </button>

      {resumen && <PopupResumen resumen={resumen} onClose={volverHome} />}
    </div>
  );
}

export default PantallaJuego;
