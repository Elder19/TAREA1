import React, { useState } from "react";

function Names({ volverHome, Continuar }) {
  const [n1, setN1] = useState("");
  const [n2, setN2] = useState("");

  const handleChange1 = (e) => setN1(e.target.value);
  const handleChange2 = (e) => setN2(e.target.value);

  const guardar = () => {
    if (!n1.trim() || !n2.trim()) return;

   //ramdom
    const asignarPrimero = Math.random() < 0.5;
    const jugadores = asignarPrimero
      ? { jugador1: n1.trim(), jugador2: n2.trim() }
      : { jugador1: n2.trim(), jugador2: n1.trim() };

    if (typeof Continuar === "function") Continuar(jugadores);
  };

  return (
    <div className="Names">
      <h2>Ingresa los nombres</h2>
      <div>
        <label>Input 1</label>
        <input value={n1} onChange={handleChange1} />
      </div>
      <div>
        <label>Input 2</label>
        <input value={n2} onChange={handleChange2} />
      </div>
      <div>
        <button className="btn-continuar" onClick={guardar}>
          Continuar
        </button>
        <button className="btn-cancelar" onClick={volverHome}>
          Cancelar
        </button>
      </div>
    </div>
  );
}

export default Names;
