import React from "react";

function Home({ iniciarJuego, verHistorial }) {
  const JuegoHistorial = () => {
    if (typeof verHistorial === "function") verHistorial();
  };

  return (
    <div className="Home">
      <header>
        <h1>Bienvenido a la batalla de numeros</h1>
      </header>
      <main>
        <button className="btn Jugar" onClick={iniciarJuego}>
          Jugar
        </button>
        <button className="btn historial" onClick={JuegoHistorial}>
          Historial de juego
        </button>
      </main>
    </div>
  );
}

export default Home;
