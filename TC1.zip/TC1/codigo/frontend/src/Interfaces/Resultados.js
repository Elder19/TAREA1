import React, { useEffect, useState } from "react";

function Resultados({ volverHome }) {
  const [cargando, setCargando] = useState(true);
  const [matches, setMatches] = useState([]);

  useEffect(() => {
    async function fetchResultados() {
      try {
        const res = await fetch("http://localhost:3001/api/resultados");
        const json = await res.json();
        setMatches(json.matchesHistory || []);
      } catch (e) {
        console.error("Error al cargar resultados:", e);
      } finally {
        setCargando(false);
      }
    }
    fetchResultados();
  }, []);

  if (cargando) return <p>Cargando resultados...</p>;
  if (!matches.length)
    return (
      <div>
        <p>No hay partidas finalizadas.</p>
        <button onClick={volverHome}>Volver</button>
      </div>
    );

  return (
    <div className="historial-partidas">
      <h2>Historial de partidas</h2>
      <table className="historial-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Fecha</th>
            <th>Jugador 1</th>
            <th>Intentos</th>
            <th>Tiempo</th>
            <th>Jugador 2</th>
            <th>Intentos</th>
            <th>Tiempo</th>
            <th>Ganador</th>
          </tr>
        </thead>
        <tbody>
          {(matches || []).map((m, idx) => {
            const jugadores = Object.values(m.stats);
            return (
              <tr key={idx}>
                <td>{idx + 1}</td>
                <td>{new Date(m.creadoEn).toLocaleString()}</td>
                <td>{jugadores[0]?.nombre}</td>
                <td>{jugadores[0]?.totalIntentos}</td>
                <td>{jugadores[0]?.totalTiempoSegundos} s</td>
                <td>{jugadores[1]?.nombre}</td>
                <td>{jugadores[1]?.totalIntentos}</td>
                <td>{jugadores[1]?.totalTiempoSegundos} s</td>
                <td className="historial-ganador">
                  {m.ganador ? m.ganador : "Empate"}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <button className="btn-cancelar" onClick={volverHome}>
        Volver
      </button>
    </div>
  );
}

export default Resultados;
